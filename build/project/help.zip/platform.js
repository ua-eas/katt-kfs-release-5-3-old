﻿var d2hServerPlatform = "jsp";
